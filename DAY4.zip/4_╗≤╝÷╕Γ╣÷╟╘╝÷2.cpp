class Rect
{
	int x, y, w, h;
public:
	int getArea()  { return w * h; }
};

void foo(Rect r)
{
	int n = r.getArea(); 
}
int main()
{
	Rect r; // �ʱ�ȭ �ߴٰ� ����..
	int n = r.getArea();
	foo(r);
}