
class Point
{
	int x, y;
public:
	Point(int a, int b) : x(a), y(b) {}
};
class Rect
{
	Point pt; // ?
public:
	Rect() {}
};
int main()
{
	Rect r1;
}

