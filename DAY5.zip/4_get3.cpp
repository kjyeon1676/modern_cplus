#include <iostream>
using namespace std;

// xtuple 
template<typename ... Types> struct xtuple
{
	static constexpr int N = 0;
};

template<typename T, typename ... Types>
struct xtuple<T, Types...> : public xtuple<Types...>
{
	T value;
	xtuple() = default;
	xtuple(const T& v, const Types& ... args) : value(v), xtuple<Types...>(args...) {}
	static constexpr int N = xtuple<Types...>::N + 1;
};


template<typename TP> void foo(TP& tp)
{
	typename xtuple_element<1, TP>::type n;

	std::cout << typeid(n).name() << std::endl;
}

int main()
{
	xtuple<int, double, char> t3(1, 3.4, 'A');
}
