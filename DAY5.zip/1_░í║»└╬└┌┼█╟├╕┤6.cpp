#include <iostream>

// 233 page �Դϴ�.

template<typename ... Types>
void foo(Types ... args)
{

}

int main()
{
	foo(1, 3.4, 'A'); 
}





