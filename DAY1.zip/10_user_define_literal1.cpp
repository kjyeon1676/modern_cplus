int main()
{
	float f = 3.4f;
}




