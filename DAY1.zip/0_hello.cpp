#include <iostream>

int main()
{
	std::cout << "hello, cpp" << std::endl;
}