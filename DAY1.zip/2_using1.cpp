#include <unordered_set>

// C ��Ÿ�� �ڵ� - typedef 
typedef int DWORD;
typedef void(*F)(); 

int main()
{
	DWORD n; 
	F     f; 
}